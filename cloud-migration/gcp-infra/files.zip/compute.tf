# ─────────────────────────────────────────────
# STARTUP SCRIPTS
# ─────────────────────────────────────────────
locals {
  postgres_startup = file("${path.module}/scripts/postgres_startup.sh")

  redis_startup = <<-EOT
    #!/bin/bash
    apt-get update -y
    apt-get install -y redis-server
    sed -i 's/bind 127.0.0.1/bind 0.0.0.0/' /etc/redis/redis.conf
    sed -i 's/# requirepass foobared/requirepass RedisSecure@2024/' /etc/redis/redis.conf
    systemctl restart redis-server
    systemctl enable redis-server
    echo "Redis setup complete" >> /var/log/startup-script.log
  EOT

  metabase_startup = <<-EOT
    #!/bin/bash
    apt-get update -y
    apt-get install -y openjdk-11-jre-headless wget
    mkdir -p /opt/metabase
    wget -O /opt/metabase/metabase.jar https://downloads.metabase.com/v0.47.0/metabase.jar
    cat > /etc/systemd/system/metabase.service <<EOF
    [Unit]
    Description=Metabase
    After=network.target
    [Service]
    ExecStart=/usr/bin/java -jar /opt/metabase/metabase.jar
    Restart=always
    Environment=MB_DB_TYPE=h2
    WorkingDirectory=/opt/metabase
    [Install]
    WantedBy=multi-user.target
    EOF
    systemctl daemon-reload
    systemctl enable metabase
    systemctl start metabase
    echo "Metabase setup complete" >> /var/log/startup-script.log
  EOT
}

# ─────────────────────────────────────────────
# PRODUCTION DATABASE (large — skipped in test account by default)
# c2d-highcpu-112, 224GB RAM, 5200GB SSD
# ─────────────────────────────────────────────
resource "google_compute_instance" "credresolve_prod_database" {
  count        = var.create_large_instances ? 1 : 0
  name         = "credresolve-prod-database"
  machine_type = "c2d-highcpu-112"
  zone         = var.zone
  tags         = ["all-db", "prod-database"]

  boot_disk {
    initialize_params {
      image = "ubuntu-os-cloud/ubuntu-2204-lts"
      size  = 5200
      type  = "pd-ssd"
    }
  }

  network_interface {
    subnetwork = google_compute_subnetwork.private.id
    # No access_config = no external IP
  }

  metadata_startup_script = local.postgres_startup

  metadata = {
    enable-oslogin = "TRUE"
  }
}

# ─────────────────────────────────────────────
# DATABASE REPLICA (large — skipped in test by default)
# c2d-highcpu-32, 64GB RAM
# ─────────────────────────────────────────────
resource "google_compute_instance" "credresolve_database_replica" {
  count        = var.create_large_instances ? 1 : 0
  name         = "credresolve-database-replica"
  machine_type = "c2d-highcpu-32"
  zone         = var.zone
  tags         = ["all-db", "prod-database", "read-only"]

  boot_disk {
    initialize_params {
      image = "ubuntu-os-cloud/ubuntu-2204-lts"
      size  = 500
      type  = "pd-ssd"
    }
  }

  network_interface {
    subnetwork = google_compute_subnetwork.private.id
  }

  metadata_startup_script = local.postgres_startup

  metadata = {
    enable-oslogin = "TRUE"
  }
}

# ─────────────────────────────────────────────
# DATA ANALYTICS DB
# c2-standard-8, 32GB RAM, 350GB Standard disk
# ─────────────────────────────────────────────
resource "google_compute_instance" "credresolve_data_analytics_db" {
  name         = "credresolve-data-analytics-db"
  machine_type = "c2-standard-8"
  zone         = var.zone
  tags         = ["all-db"]

  boot_disk {
    initialize_params {
      image = "ubuntu-os-cloud/ubuntu-2204-lts"
      size  = 350
      type  = "pd-standard" # Standard disk as in original
    }
  }

  network_interface {
    subnetwork = google_compute_subnetwork.private.id
  }

  metadata_startup_script = local.postgres_startup

  metadata = {
    enable-oslogin = "TRUE"
  }
}

# ─────────────────────────────────────────────
# COMMUNICATION PROD DATABASE
# n2d-highcpu-4, 4GB RAM, 30GB SSD
# ─────────────────────────────────────────────
resource "google_compute_instance" "communication_prod_database" {
  name         = "communication-prod-database"
  machine_type = "n2d-highcpu-4"
  zone         = var.zone
  tags         = ["all-db", "prod-database"]

  boot_disk {
    initialize_params {
      image = "ubuntu-os-cloud/ubuntu-2204-lts"
      size  = 30
      type  = "pd-ssd"
    }
  }

  network_interface {
    subnetwork = google_compute_subnetwork.private.id
  }

  metadata_startup_script = local.postgres_startup

  metadata = {
    enable-oslogin = "TRUE"
  }
}

# ─────────────────────────────────────────────
# NAADH PRODUCTION DATABASE
# n2-custom-16-8192, 8GB RAM, 30GB SSD
# ─────────────────────────────────────────────
resource "google_compute_instance" "naadh_production_database" {
  name         = "naadh-production-database"
  machine_type = "n2-custom-16-8192"
  zone         = var.zone
  tags         = ["all-db", "prod-database"]

  boot_disk {
    initialize_params {
      image = "projects/ubuntu-os-cloud/global/images/ubuntu-minimal-2204-jammy-v20251204"
      size  = 30
      type  = "pd-ssd"
    }
  }

  network_interface {
    subnetwork = google_compute_subnetwork.private.id
  }

  metadata_startup_script = local.postgres_startup

  metadata = {
    enable-oslogin = "TRUE"
  }
}

# ─────────────────────────────────────────────
# NAADH DATABASE STAGE
# n2d-highcpu-4, 4GB RAM, 30GB SSD
# ─────────────────────────────────────────────
resource "google_compute_instance" "naadh_database_stage" {
  name         = "naadh-database-stage"
  machine_type = "n2d-highcpu-4"
  zone         = var.zone
  tags         = ["all-db"]

  boot_disk {
    initialize_params {
      image = "ubuntu-os-cloud/ubuntu-2204-lts"
      size  = 30
      type  = "pd-ssd"
    }
  }

  network_interface {
    subnetwork = google_compute_subnetwork.private.id
  }

  metadata_startup_script = local.postgres_startup

  metadata = {
    enable-oslogin = "TRUE"
  }
}

# ─────────────────────────────────────────────
# CREDRESOLVE TINY DB
# n2d-highcpu-2, 2GB RAM, 10GB SSD
# ─────────────────────────────────────────────
resource "google_compute_instance" "credresolve_tiny_db" {
  name         = "credresolve-tiny-db"
  machine_type = "n2d-highcpu-2"
  zone         = var.zone
  tags         = ["all-db"]

  boot_disk {
    initialize_params {
      image = "ubuntu-os-cloud/ubuntu-2204-lts"
      size  = 10
      type  = "pd-ssd"
    }
  }

  network_interface {
    subnetwork = google_compute_subnetwork.private.id
  }

  metadata_startup_script = local.postgres_startup

  metadata = {
    enable-oslogin = "TRUE"
  }
}

# ─────────────────────────────────────────────
# REDIS SERVER (production)
# n2-standard-4, 16GB RAM, 50GB SSD
# ─────────────────────────────────────────────
resource "google_compute_instance" "redis_server" {
  name         = "redis-server"
  machine_type = "n2-standard-4"
  zone         = var.zone
  tags         = ["redis"]

  boot_disk {
    initialize_params {
      image = "ubuntu-os-cloud/ubuntu-2204-lts"
      size  = 50
      type  = "pd-ssd"
    }
  }

  network_interface {
    subnetwork = google_compute_subnetwork.private.id
  }

  metadata_startup_script = local.redis_startup

  metadata = {
    enable-oslogin = "TRUE"
  }
}

# ─────────────────────────────────────────────
# REDIS SERVER STAGE
# n2d-highcpu-4, 4GB RAM, 50GB SSD
# ─────────────────────────────────────────────
resource "google_compute_instance" "redis_server_stage" {
  name         = "redis-server-stage"
  machine_type = "n2d-highcpu-4"
  zone         = var.zone
  tags         = ["redis"]

  boot_disk {
    initialize_params {
      image = "ubuntu-os-cloud/ubuntu-2204-lts"
      size  = 50
      type  = "pd-ssd"
    }
  }

  network_interface {
    subnetwork = google_compute_subnetwork.private.id
  }

  metadata_startup_script = local.redis_startup

  metadata = {
    enable-oslogin = "TRUE"
  }
}

# ─────────────────────────────────────────────
# METABASE
# n2-custom-2-4096, 4GB RAM, 300GB SSD
# ─────────────────────────────────────────────
resource "google_compute_instance" "credresolve_metabase" {
  name         = "credresolve-metabase"
  machine_type = "n2-custom-2-4096"
  zone         = var.zone
  tags         = ["metabase"]

  boot_disk {
    initialize_params {
      image = "ubuntu-os-cloud/ubuntu-2204-lts"
      size  = 300
      type  = "pd-ssd"
    }
  }

  network_interface {
    subnetwork = google_compute_subnetwork.private.id
  }

  metadata_startup_script = local.metabase_startup

  metadata = {
    enable-oslogin = "TRUE"
  }
}
